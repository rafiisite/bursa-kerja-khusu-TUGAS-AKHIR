

<?php $__env->startSection('content'); ?>
    <div style="text-align: center; display: flex; justify-content: center; align-items:center; height: 100vh;">
        <div>
            <h1>You Dont Have Access.</h1>
            <p>Please Login to Access Your Account!</p>
            <a href="/login" class="form-control bg-primary text-white" style="font-size: 18px;">Login</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rapii\Documents\idk\resources\views/errors/access.blade.php ENDPATH**/ ?>