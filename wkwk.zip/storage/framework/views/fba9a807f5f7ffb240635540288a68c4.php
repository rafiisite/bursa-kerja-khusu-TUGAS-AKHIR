

<?php $__env->startSection('content'); ?>
    <?php if($user->role === 'admin'): ?>
        <?php echo $__env->make('layout.dash.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <h1>Welcome User</h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rapii\Documents\idk\resources\views/dashboard.blade.php ENDPATH**/ ?>