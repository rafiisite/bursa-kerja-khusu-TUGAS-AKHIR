@extends('layout.head')

@section('content')
    <h1>hello world</h1>
@endsection